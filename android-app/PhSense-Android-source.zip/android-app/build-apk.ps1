param(
    [string]$Sdk = '',
    [string]$Jdk = 'C:/Program Files/Android/Android Studio/jbr',
    [string]$DebugKeystore = "$env:USERPROFILE/.android/debug.keystore"
)
# Dependency-free SDK build fallback. Only generated files under this project are written.
$ErrorActionPreference = 'Stop'
$project = $PSScriptRoot
if (-not $Sdk) {
    $localConfig = Join-Path $project 'local.properties'
    $sdkSetting = if (Test-Path -LiteralPath $localConfig) { Get-Content -LiteralPath $localConfig | Where-Object { $_ -match '^sdk.dir=' } | Select-Object -First 1 }
    if ($sdkSetting) { $Sdk = $sdkSetting.Substring(8).Replace('\:',':').Replace('\\','\') }
    else { $Sdk = "$env:LOCALAPPDATA/Android/Sdk" }
}
$build = Join-Path $project 'app/build/sdk-build'
$classes = Join-Path $build 'classes'
$dex = Join-Path $build 'dex'
$tools = Join-Path $Sdk 'build-tools/35.0.0'
$platform = Join-Path $Sdk 'platforms/android-35/android.jar'
$env:JAVA_HOME = $Jdk
function Run-Checked([string]$Exe, [string[]]$Arguments) {
    & $Exe @Arguments
    if ($LASTEXITCODE -ne 0) { throw "$Exe failed with exit code $LASTEXITCODE" }
}
New-Item -ItemType Directory -Force $classes,$dex | Out-Null
$sources = @(Get-ChildItem (Join-Path $project 'app/src/main/java/sg/edu/nus/phsense') -Filter '*.java' | ForEach-Object FullName)
Run-Checked (Join-Path $Jdk 'bin/javac.exe') (@('-encoding','UTF-8','--release','17','-cp',$platform,'-d',$classes) + $sources)
$testClasses = Join-Path $build 'tests'
New-Item -ItemType Directory -Force $testClasses | Out-Null
Run-Checked (Join-Path $Jdk 'bin/javac.exe') @('-encoding','UTF-8','--release','17','-cp',$classes,'-d',$testClasses,(Join-Path $project 'tests/ProtocolTest.java'))
Run-Checked (Join-Path $Jdk 'bin/java.exe') @('-cp',"$classes;$testClasses",'sg.edu.nus.phsense.ProtocolTest')
$jar = Join-Path $build 'classes.jar'
Run-Checked (Join-Path $Jdk 'bin/jar.exe') @("-J-Djava.io.tmpdir=$build",'--create','--file',$jar,'-C',$classes,'.')
Run-Checked (Join-Path $tools 'd8.bat') @('--debug','--min-api','26','--lib',$platform,'--output',$dex,$jar)
[xml]$manifest = Get-Content -LiteralPath (Join-Path $project 'app/src/main/AndroidManifest.xml') -Raw
$androidNs = 'http://schemas.android.com/apk/res/android'
$manifest.manifest.SetAttribute('package','sg.edu.nus.phsense')
$manifest.manifest.SetAttribute('versionCode',$androidNs,'2') | Out-Null
$manifest.manifest.SetAttribute('versionName',$androidNs,'0.2.0-rssi') | Out-Null
$generatedManifest = Join-Path $build 'AndroidManifest.xml'
$manifest.Save($generatedManifest)
$unsigned = Join-Path $build 'unsigned.apk'
Run-Checked (Join-Path $tools 'aapt2.exe') @('link','-I',$platform,'--manifest',$generatedManifest,'--min-sdk-version','26','--target-sdk-version','35','-o',$unsigned)
Push-Location $dex
try { Run-Checked (Join-Path $tools 'aapt.exe') @('add',$unsigned,'classes.dex') }
finally { Pop-Location }
$aligned = Join-Path $build 'aligned.apk'
Run-Checked (Join-Path $tools 'zipalign.exe') @('-f','-p','4',$unsigned,$aligned)
$output = Join-Path $project 'app/build/outputs/apk/debug'
New-Item -ItemType Directory -Force $output | Out-Null
$apk = Join-Path $output 'app-debug.apk'
Run-Checked (Join-Path $tools 'apksigner.bat') @('sign','--ks',$DebugKeystore,'--ks-key-alias','androiddebugkey','--ks-pass','pass:android','--key-pass','pass:android','--out',$apk,$aligned)
Run-Checked (Join-Path $tools 'apksigner.bat') @('verify','--verbose',$apk)
Run-Checked (Join-Path $tools 'aapt.exe') @('dump','badging',$apk)
Get-Item -LiteralPath $apk | Select-Object FullName,Length,LastWriteTime
