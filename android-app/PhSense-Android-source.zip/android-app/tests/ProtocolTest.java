package sg.edu.nus.phsense;

import java.util.Arrays;

public final class ProtocolTest {
    private static int checks;
    private static void check(boolean condition) { checks++; if(!condition) throw new AssertionError("Check "+checks); }
    private static void rejects(Runnable action) {
        checks++;
        try { action.run(); } catch(IllegalArgumentException expected) { return; }
        throw new AssertionError("Expected rejection at check "+checks);
    }
    public static void main(String[] args) {
        check(Protocol.interval("0.1")==100); check(Protocol.interval("24")==24000);
        check(Protocol.interval(" 1.234 ")==1234); check(Protocol.interval("00.100")==100);
        for(String bad:new String[]{"0","0.099","24.001","1.0001","NaN","1e2","-1","","999999999999"})
            rejects(()->Protocol.interval(bad));
        int[] gains={0,1,2,3,0,1,2,3};
        Protocol.Settings s=new Protocol.Settings(24000,0x85,gains,false);
        byte[] command=s.command();
        check(command.length==13); check((command[0]&255)==0xc3); check(command[1]==2);
        check((command[2]&255)==0x85); check((command[3]&255)==0xc0); check((command[4]&255)==0x5d);
        byte[] ack=Arrays.copyOf(command,14); ack[0]=(byte)0xc4; ack[13]=1;
        Protocol.Settings parsed=Protocol.settings(ack);
        check(parsed.running&&parsed.matches(s)); check(Arrays.equals(parsed.gains,gains));
        gains[0]=3; check(s.gains[0]==0);
        rejects(()->Protocol.settings(Arrays.copyOf(ack,13)));
        ack[13]=2; rejects(()->Protocol.settings(ack)); ack[13]=0;
        ack[5]=4; rejects(()->Protocol.settings(ack));
        rejects(()->new Protocol.Settings(99,255,new int[8],false));
        rejects(()->new Protocol.Settings(24001,255,new int[8],false));
        rejects(()->new Protocol.Settings(100,256,new int[8],false));
        check(new Protocol.Settings(100,0,new int[8],false).mask==0);
        byte[] sample={(byte)0xa5,3,(byte)255,2,7,(byte)0xff,(byte)0xff,
                (byte)0xff,(byte)0xff,(byte)0xff,(byte)0xff,0,0,0,(byte)0x80};
        Protocol.Sample p=new Protocol.Sample(sample);
        check(p.channel==7&&p.gain==3&&p.sequence==255); check(p.millivolts==65535);
        check(p.deviceTime==4294967295L); check(p.cycle==2147483648L);
        sample[5]=0x34; sample[6]=0x12; check(new Protocol.Sample(sample).millivolts==0x1234);
        rejects(()->new Protocol.Sample(Arrays.copyOf(sample,14)));
        sample[4]=8; rejects(()->new Protocol.Sample(sample)); sample[4]=0;
        sample[1]=4; rejects(()->new Protocol.Sample(sample)); sample[1]=0;
        sample[3]=1; rejects(()->new Protocol.Sample(sample));
        for(int channel=0;channel<8;channel++) for(int gain=0;gain<4;gain++) {
            sample[1]=(byte)gain; sample[3]=2; sample[4]=(byte)channel;
            Protocol.Sample value=new Protocol.Sample(sample);
            check(value.channel==channel&&value.gain==gain);
        }
        Telemetry.RssiStats stats=new Telemetry.RssiStats();
        stats.add(-50); stats.add(-60); stats.add(-70);
        check(stats.count==3&&stats.mean==-60&&stats.min==-70&&stats.max==-50);
        check(Math.abs(stats.sd()-10)<0.000001);
        stats.clear(); check(stats.count==0&&stats.sd()==0); stats.add(-90); check(stats.mean==-90);
        rejects(()->stats.add(127));
        sample[1]=2; sample[3]=2; sample[4]=4; sample[5]=0x34; sample[6]=0x12;
        Protocol.Sample valid=new Protocol.Sample(sample);
        String[] fields=Telemetry.row("sample","2026-10-21T10:00:00+08:00",1.25,2,"AA:BB",valid,-75,150,null).trim().split(",",-1);
        check(fields.length==14&&Telemetry.HEADER.trim().split(",").length==14);
        check(fields[5].equals("4")&&fields[6].equals("100")&&fields[7].equals("4660"));
        check(fields[8].equals("1")&&fields[12].equals("-75")&&fields[13].equals("150"));
        String stale=Telemetry.row("sample","time",1,2,"AA",valid,-75,3001,null);
        check(stale.endsWith(",,\n"));
        String failedRssi=Telemetry.row("rssi_unavailable","time",1,2,"AA",null,null,0,null);
        check(failedRssi.endsWith(",,\n"));
        String signal=Telemetry.row("rssi","time",1,2,"AA",null,null,0,-80);
        check(signal.endsWith(",-80,0\n"));
        sample[5]=(byte)255; sample[6]=(byte)255;
        String[] invalid=Telemetry.row("sample","time",1,2,"AA",new Protocol.Sample(sample),null,0,null).trim().split(",",-1);
        check(invalid[7].isEmpty()&&invalid[8].equals("0"));
        System.out.println("PASS: "+checks+" protocol checks");
    }
}
