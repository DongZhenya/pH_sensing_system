package sg.edu.nus.phsense;

import java.math.BigDecimal;
import java.util.Arrays;

/** Current wired-firmware protocol; independently testable without Android. */
final class Protocol {
    static final int[] GAINS = {25, 50, 100, 200};
    static int interval(String text) {
        if (!text.trim().matches("[0-9]+(?:\\.[0-9]{1,3})?"))
            throw new IllegalArgumentException("Enter seconds with up to 3 decimal places.");
        int ms;
        try { ms = new BigDecimal(text.trim()).movePointRight(3).intValueExact(); }
        catch (ArithmeticException e) { throw new IllegalArgumentException("Interval must be 0.1–24 s."); }
        if (ms < 100 || ms > 24000) throw new IllegalArgumentException("Interval must be 0.1–24 s.");
        return ms;
    }
    static final class Settings {
        final int interval, mask;
        final int[] gains;
        final boolean running;
        Settings(int interval, int mask, int[] gains, boolean running) {
            if (interval < 100 || interval > 24000 || mask < 0 || mask > 255 || gains.length != 8)
                throw new IllegalArgumentException("Invalid device settings.");
            for (int g : gains) if (g < 0 || g > 3) throw new IllegalArgumentException("Invalid gain.");
            this.interval=interval; this.mask=mask; this.gains=gains.clone(); this.running=running;
        }
        boolean matches(Settings other) {
            return interval==other.interval && mask==other.mask && Arrays.equals(gains,other.gains);
        }
        byte[] command() {
            byte[] b=new byte[13]; b[0]=(byte)0xc3; b[1]=2; b[2]=(byte)mask;
            b[3]=(byte)interval; b[4]=(byte)(interval>>8);
            for(int i=0;i<8;i++) b[i+5]=(byte)gains[i];
            return b;
        }
    }
    static Settings settings(byte[] b) {
        if(b.length!=14 || (b[0]&255)!=0xc4 || b[1]!=2 || (b[13]!=0 && b[13]!=1))
            throw new IllegalArgumentException("Matching Start-enabled firmware is required.");
        int[] gains=new int[8]; for(int i=0;i<8;i++) gains[i]=b[i+5]&255;
        return new Settings(u16(b,3),b[2]&255,gains,b[13]==1);
    }
    static final class Sample {
        final int gain,sequence,channel,millivolts;
        final long deviceTime,cycle;
        Sample(byte[] b) {
            if(b.length!=15 || (b[0]&255)!=0xa5 || b[3]!=2) throw new IllegalArgumentException("Unsupported sample frame.");
            gain=b[1]&255; sequence=b[2]&255; channel=b[4]&255;
            if(gain>3 || channel>7) throw new IllegalArgumentException("Invalid sample channel/gain.");
            millivolts=u16(b,5); deviceTime=u32(b,7); cycle=u32(b,11);
        }
    }
    private static int u16(byte[] b,int n) { return (b[n]&255)|((b[n+1]&255)<<8); }
    private static long u32(byte[] b,int n) { return (long)u16(b,n)|((long)u16(b,n+2)<<16); }
}
