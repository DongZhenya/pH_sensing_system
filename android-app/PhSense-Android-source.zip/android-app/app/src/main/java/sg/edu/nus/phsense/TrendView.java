package sg.edu.nus.phsense;

import android.content.Context;
import android.graphics.*;
import android.view.View;
import java.util.ArrayList;
import java.util.Locale;

/** Cumulative raw points: no rolling window, averaging, decimation or history cap. */
final class TrendView extends View {
    static final int[] COLORS={0xffd84343,0xffd07814,0xff8c8a00,0xff278248,0xff0097a7,0xff2868c6,0xff8e42b5,0xffc23d7e};
    private final ArrayList<double[]> points=new ArrayList<>();
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final String unit;
    private final int color;
    private double origin,end;
    private boolean redrawScheduled;
    TrendView(Context context,String unit,int color) { super(context); this.unit=unit; this.color=color; setBackgroundColor(Color.WHITE); }
    void add(double time,double value) {
        points.add(new double[]{time,value}); end=Math.max(end,time);
        // Throttle rendering only. Every original point remains stored and drawn.
        if(!redrawScheduled) { redrawScheduled=true; postInvalidateDelayed(200); }
    }
    void clear(double time) { points.clear(); origin=end=time; invalidate(); }
    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        redrawScheduled=false;
        float d=getResources().getDisplayMetrics().density;
        float left=62*d,right=getWidth()-12*d,top=20*d,bottom=getHeight()-30*d;
        if(right<=left||bottom<=top) return;
        double min=Double.POSITIVE_INFINITY,max=Double.NEGATIVE_INFINITY;
        for(double[] p:points) if(Double.isFinite(p[1])) { min=Math.min(min,p[1]); max=Math.max(max,p[1]); }
        if(!Double.isFinite(min)) { min=unit.equals("dBm")?-100:0; max=unit.equals("dBm")?-30:3300; }
        double margin=Math.max(unit.equals("dBm")?2:1,(max-min)*0.1); min-=margin; max+=margin;
        double span=Math.max(1,end-origin);
        paint.setStrokeWidth(d); paint.setTextSize(11*d); paint.setStyle(Paint.Style.FILL);
        for(int i=0;i<=4;i++) {
            float y=top+(bottom-top)*i/4;
            paint.setColor(0xffe4ebf0); canvas.drawLine(left,y,right,y,paint);
            paint.setColor(0xff526575); canvas.drawText(String.format(Locale.US,"%.1f",max-(max-min)*i/4),3*d,y+4*d,paint);
        }
        canvas.drawText(unit,3*d,12*d,paint); canvas.drawText("0 s",left,getHeight()-7*d,paint);
        String label=String.format(Locale.US,"%.1f s",span);
        canvas.drawText(label,right-paint.measureText(label),getHeight()-7*d,paint);
        Path path=new Path(); boolean connected=false;
        canvas.save(); canvas.clipRect(left,top,right,bottom); paint.setColor(color);
        for(double[] p:points) {
            if(!Double.isFinite(p[1])) { connected=false; continue; }
            float x=left+(right-left)*(float)((p[0]-origin)/span);
            float y=bottom-(bottom-top)*(float)((p[1]-min)/(max-min));
            if(connected) path.lineTo(x,y); else path.moveTo(x,y);
            connected=true; canvas.drawCircle(x,y,1.5f*d,paint);
        }
        paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(1.5f*d); canvas.drawPath(path,paint); canvas.restore();
    }
}
