package sg.edu.nus.phsense;

import android.annotation.SuppressLint;
import android.bluetooth.*;
import android.bluetooth.le.*;
import android.content.Context;
import android.os.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.UUID;

/** All GATT operations, including RSSI reads, are serialized on the main thread. */
@SuppressLint("MissingPermission")
final class BleClient {
    static final UUID SERVICE=UUID.fromString("f000c0c0-0451-4000-b000-000000000000");
    private static final UUID WRITE=UUID.fromString("f000c0c1-0451-4000-b000-000000000000");
    private static final UUID NOTIFY=UUID.fromString("f000c0c2-0451-4000-b000-000000000000");
    private static final UUID CCC=UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");
    interface Listener {
        void onStatus(String text);
        void onDevice(BluetoothDevice device,String name,int scanRssi);
        void onData(byte[] data);
        void onRssi(Integer rssi);
        void onReady();
        void onDisconnected();
    }
    private final Context context;
    private final Listener listener;
    private final Handler main=new Handler(Looper.getMainLooper());
    private final BluetoothAdapter adapter;
    private final ArrayDeque<byte[]> pending=new ArrayDeque<>();
    private BluetoothLeScanner scanner;
    private BluetoothGatt gatt;
    private BluetoothGattCharacteristic writer;
    private boolean ready,writeBusy,rssiBusy;
    private long lastRssiAttempt;
    private final Runnable scanEnd=this::stopScan;
    private final Runnable operationTimeout=this::operationTimedOut;
    private void operationTimedOut() {
        if(writeBusy||rssiBusy) { listener.onStatus("Bluetooth operation timed out. Reconnect to retry."); disconnect(); }
    }
    private final Runnable connectionTimeout=this::connectionTimedOut;
    private void connectionTimedOut() {
        if(gatt!=null&&!ready) { listener.onStatus("Connection/setup timed out."); disconnect(); }
    }
    private final Runnable rssiPoll=new Runnable() {
        @Override public void run() { if(ready) { pump(); main.postDelayed(this,250); } }
    };
    BleClient(Context context,Listener listener) {
        this.context=context; this.listener=listener;
        BluetoothManager manager=(BluetoothManager)context.getSystemService(Context.BLUETOOTH_SERVICE);
        adapter=manager==null?null:manager.getAdapter();
    }
    void startScan() {
        stopScan();
        if(gatt!=null) { listener.onStatus("Disconnect before scanning again."); return; }
        if(adapter==null||!adapter.isEnabled()) { listener.onStatus("Enable Bluetooth first."); return; }
        scanner=adapter.getBluetoothLeScanner();
        if(scanner==null) { listener.onStatus("Bluetooth scanner unavailable."); return; }
        scanner.startScan(scanCallback); listener.onStatus("Scanning for CC2340 devices…"); main.postDelayed(scanEnd,12000);
    }
    void stopScan() {
        main.removeCallbacks(scanEnd);
        if(scanner!=null) { scanner.stopScan(scanCallback); scanner=null; }
    }
    void connect(BluetoothDevice device) {
        stopScan(); disconnect(); listener.onStatus("Connecting to "+device.getAddress()+"…");
        gatt=device.connectGatt(context,false,callback,BluetoothDevice.TRANSPORT_LE);
        main.postDelayed(connectionTimeout,20000);
    }
    void disconnect() {
        main.removeCallbacks(rssiPoll); main.removeCallbacks(operationTimeout); main.removeCallbacks(connectionTimeout);
        ready=writeBusy=rssiBusy=false; writer=null; pending.clear();
        BluetoothGatt old=gatt; gatt=null;
        if(old!=null) { old.disconnect(); old.close(); }
        listener.onRssi(null); listener.onDisconnected();
    }
    void send(String command) { send(command.getBytes(StandardCharsets.US_ASCII)); }
    void send(byte[] command) {
        if(!ready) { listener.onStatus("Device is not ready."); return; }
        if(pending.size()>=16) { listener.onStatus("Command queue full; wait and retry."); return; }
        pending.add(command.clone()); pump();
    }
    private void pump() {
        if(!ready||gatt==null||writeBusy||rssiBusy) return;
        if(!pending.isEmpty()) {
            byte[] b=pending.peek(); int type=BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT;
            writeBusy=true; boolean started;
            if(Build.VERSION.SDK_INT>=33) started=gatt.writeCharacteristic(writer,b,type)==BluetoothStatusCodes.SUCCESS;
            else { writer.setWriteType(type); writer.setValue(b); started=gatt.writeCharacteristic(writer); }
            if(!started) { listener.onStatus("Unable to send command. Reconnect to retry."); disconnect(); return; }
            main.postDelayed(operationTimeout,8000);
        } else if(SystemClock.elapsedRealtime()-lastRssiAttempt>=1000) {
            lastRssiAttempt=SystemClock.elapsedRealtime(); rssiBusy=true;
            if(gatt.readRemoteRssi()) main.postDelayed(operationTimeout,5000);
            else { rssiBusy=false; listener.onRssi(null); }
        }
    }
    private final ScanCallback scanCallback=new ScanCallback() {
        @Override public void onScanResult(int type,ScanResult result) {
            main.post(()->{
                if(scanner==null) return;
                String name=result.getScanRecord()==null?null:result.getScanRecord().getDeviceName();
                if(name==null) name=result.getDevice().getName();
                listener.onDevice(result.getDevice(),name==null?"Unnamed device":name,result.getRssi());
            });
        }
        @Override public void onScanFailed(int error) { main.post(()->listener.onStatus("Scan failed: "+error)); }
    };
    private final BluetoothGattCallback callback=new BluetoothGattCallback() {
        @Override public void onConnectionStateChange(BluetoothGatt source,int status,int state) {
            main.post(()->{
                if(source!=gatt) return;
                if(status==BluetoothGatt.GATT_SUCCESS&&state==BluetoothProfile.STATE_CONNECTED) {
                    listener.onStatus("Connected. Discovering services…");
                    if(!source.discoverServices()) { listener.onStatus("Service discovery failed."); disconnect(); }
                } else { listener.onStatus("Disconnected (status "+status+")."); disconnect(); }
            });
        }
        @Override public void onServicesDiscovered(BluetoothGatt source,int status) {
            main.post(()->{
                if(source!=gatt) return;
                BluetoothGattService service=source.getService(SERVICE);
                writer=service==null?null:service.getCharacteristic(WRITE);
                BluetoothGattCharacteristic notify=service==null?null:service.getCharacteristic(NOTIFY);
                BluetoothGattDescriptor descriptor=notify==null?null:notify.getDescriptor(CCC);
                if(status!=BluetoothGatt.GATT_SUCCESS||writer==null||descriptor==null||!source.setCharacteristicNotification(notify,true)) {
                    listener.onStatus("Required Data Stream service unavailable."); disconnect(); return;
                }
                boolean started;
                if(Build.VERSION.SDK_INT>=33) started=source.writeDescriptor(descriptor,BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE)==BluetoothStatusCodes.SUCCESS;
                else { descriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE); started=source.writeDescriptor(descriptor); }
                if(!started) { listener.onStatus("Notification subscription failed."); disconnect(); }
            });
        }
        @Override public void onDescriptorWrite(BluetoothGatt source,BluetoothGattDescriptor descriptor,int status) {
            main.post(()->{
                if(source!=gatt||!CCC.equals(descriptor.getUuid())) return;
                if(status!=BluetoothGatt.GATT_SUCCESS) { listener.onStatus("Notification subscription failed."); disconnect(); return; }
                ready=true; lastRssiAttempt=0; main.removeCallbacks(connectionTimeout);
                listener.onReady(); send("Q"); main.post(rssiPoll);
            });
        }
        @Override public void onCharacteristicWrite(BluetoothGatt source,BluetoothGattCharacteristic c,int status) {
            main.post(()->{
                if(source!=gatt||!WRITE.equals(c.getUuid())) return;
                main.removeCallbacks(operationTimeout); writeBusy=false; pending.poll();
                if(status!=BluetoothGatt.GATT_SUCCESS) { listener.onStatus("Command write failed: "+status); disconnect(); }
                else pump();
            });
        }
        @Override public void onReadRemoteRssi(BluetoothGatt source,int rssi,int status) {
            main.post(()->{
                if(source!=gatt||!rssiBusy) return;
                main.removeCallbacks(operationTimeout); rssiBusy=false;
                listener.onRssi(status==BluetoothGatt.GATT_SUCCESS&&rssi>=-127&&rssi<=20?rssi:null);
                pump();
            });
        }
        @Override public void onCharacteristicChanged(BluetoothGatt s,BluetoothGattCharacteristic c,byte[] b) { deliver(s,c,b); }
        @Override public void onCharacteristicChanged(BluetoothGatt s,BluetoothGattCharacteristic c) {
            if(Build.VERSION.SDK_INT<33) deliver(s,c,c.getValue());
        }
    };
    private void deliver(BluetoothGatt source,BluetoothGattCharacteristic c,byte[] data) {
        if(!NOTIFY.equals(c.getUuid())||data==null) return;
        byte[] copy=data.clone(); main.post(()->{ if(source==gatt) listener.onData(copy); });
    }
}
