package sg.edu.nus.phsense;

import java.util.Arrays;
import java.util.Locale;

/** CSV and RSSI statistics independent of Android; failed reads are never converted to zero. */
final class Telemetry {
    static final String HEADER="event,phone_time,elapsed_s,connection_id,device_address,channel,gain_v_per_v,vsen_mv,adc_valid,sequence,device_time_ms,cycle,rssi_dbm,rssi_age_ms\n";
    static final class RssiStats {
        long count;
        int min=Integer.MAX_VALUE,max=Integer.MIN_VALUE;
        double mean,m2;
        void add(int rssi) {
            if(rssi < -127 || rssi > 20) throw new IllegalArgumentException("Invalid RSSI.");
            count++; double delta=rssi-mean; mean+=delta/count; m2+=delta*(rssi-mean);
            min=Math.min(min,rssi); max=Math.max(max,rssi);
        }
        double sd() { return count>1?Math.sqrt(m2/(count-1)):0; }
        void clear() { count=0; mean=m2=0; min=Integer.MAX_VALUE; max=Integer.MIN_VALUE; }
    }
    static String row(String event,String time,double seconds,long connection,String address,
                      Protocol.Sample sample,Integer latestRssi,long age,Integer standaloneRssi) {
        String[] v=new String[14]; Arrays.fill(v,"");
        v[0]=event; v[1]=time; v[2]=String.format(Locale.US,"%.3f",seconds);
        v[3]=Long.toString(connection); v[4]=address;
        if(sample!=null) {
            v[5]=""+sample.channel; v[6]=""+Protocol.GAINS[sample.gain];
            v[7]=sample.millivolts==0xffff?"":""+sample.millivolts;
            v[8]=sample.millivolts==0xffff?"0":"1"; v[9]=""+sample.sequence;
            v[10]=""+sample.deviceTime; v[11]=""+sample.cycle;
            if(latestRssi!=null&&age>=0&&age<=3000) { v[12]=""+latestRssi; v[13]=""+age; }
        }
        if(standaloneRssi!=null) { v[12]=""+standaloneRssi; v[13]="0"; }
        return String.join(",",v)+"\n";
    }
}
