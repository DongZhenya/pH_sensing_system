package sg.edu.nus.phsense;

import android.Manifest;
import android.app.*;
import android.bluetooth.BluetoothDevice;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;

/** Phone-only BLE central. The computer must disconnect before this app connects. */
public final class MainActivity extends Activity implements BleClient.Listener {
    private static final int PERMISSIONS=1,EXPORT=2,RECORD=3;
    private static final String HEADER=Telemetry.HEADER;
    private final Handler main=new Handler(Looper.getMainLooper());
    private final ArrayList<String> history=new ArrayList<>();
    private final ArrayList<BluetoothDevice> devices=new ArrayList<>();
    private final ArrayList<String> names=new ArrayList<>();
    private final CheckBox[] enabled=new CheckBox[8];
    private final Spinner[] gains=new Spinner[8];
    private final TextView[] values=new TextView[8];
    private final TrendView[] charts=new TrendView[8];
    private final SimpleDateFormat iso=new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX",Locale.US);
    private BleClient ble;
    private TextView status,rssiText,rssiStats,schedule,recordStatus;
    private EditText interval;
    private Button start,stop,apply,record;
    private TrendView rssiChart;
    private ArrayAdapter<String> scanAdapter;
    private boolean connected,syncing,closing;
    private Protocol.Settings applied,target;
    private boolean startAfterConfig;
    private Boolean runTarget;
    private Integer latestRssi;
    private long latestRssiTime,origin,sampleCount,connectionId;
    private final Telemetry.RssiStats signalStats=new Telemetry.RssiStats();
    private String address="";
    private Writer recording;
    private final Runnable commandTimeout=()->{
        if(target!=null||runTarget!=null) {
            target=null; runTarget=null; startAfterConfig=false; applied=null;
            onStatus("No settings acknowledgement. Disconnect and reconnect before retrying."); refresh();
        }
    };
    private final Runnable liveApply=()->applySettings(false);
    private final Runnable staleRssi=new Runnable() {
        @Override public void run() {
            if(connected&&latestRssi!=null&&SystemClock.elapsedRealtime()-latestRssiTime>3000)
                rssiText.setText("RSSI: unavailable (last reading is stale)");
            main.postDelayed(this,1000);
        }
    };
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        ble=new BleClient(this,this); origin=SystemClock.elapsedRealtime();
        buildUi(); refresh(); main.post(staleRssi);
    }
    private int dp(int n) { return Math.round(n*getResources().getDisplayMetrics().density); }
    private TextView label(String text,int size) {
        TextView v=new TextView(this); v.setText(text); v.setTextSize(size); v.setTextColor(0xff193c52); v.setPadding(0,dp(6),0,dp(6)); return v;
    }
    private Button button(String text,Runnable action) {
        Button b=new Button(this); b.setText(text); b.setAllCaps(false); b.setOnClickListener(v->action.run()); return b;
    }
    private LinearLayout row(LinearLayout parent) {
        LinearLayout v=new LinearLayout(this); v.setOrientation(LinearLayout.HORIZONTAL); parent.addView(v); return v;
    }
    private void add(LinearLayout row,View view) { row.addView(view,new LinearLayout.LayoutParams(0,-2,1)); }
    private void buildUi() {
        ScrollView scroll=new ScrollView(this);
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(14),dp(12),dp(14),dp(18));
        root.setBackgroundColor(0xfff1f6fa); scroll.addView(root); setContentView(scroll);
        scroll.setOnApplyWindowInsetsListener((v,insets)->{
            if(Build.VERSION.SDK_INT>=30) {
                android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.systemBars());
                v.setPadding(bars.left,bars.top,bars.right,bars.bottom);
            } else v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());
            return insets;
        });
        root.addView(label("pH Sense · BLE Monitor",25)); status=label("Disconnected",14); root.addView(status);
        root.addView(label("Disconnect the Windows app before connecting this phone. Keep this app open while recording.",12));
        LinearLayout connection=row(root);
        add(connection,button("Scan / Connect",this::requestScan));
        add(connection,button("Disconnect",()->{ ble.disconnect(); onStatus("Disconnected."); }));
        rssiText=label("RSSI: — dBm",23); root.addView(rssiText);
        rssiStats=label("Connected RSSI · approximately 1 reading/s",12); root.addView(rssiStats);
        rssiChart=new TrendView(this,"dBm",0xff2364b3); rssiChart.clear(seconds()); root.addView(rssiChart,new LinearLayout.LayoutParams(-1,dp(170)));
        root.addView(label("RSSI is received by this phone from the connected PCB, not measured transmit power. Scan RSSI is not included.",12));
        root.addView(label("Sampling settings",20));
        LinearLayout period=row(root); add(period,label("Cycle T (s)",16));
        interval=new EditText(this); interval.setSingleLine(true); interval.setText("1.0");
        interval.setInputType(android.text.InputType.TYPE_CLASS_NUMBER|android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
        add(period,interval);
        root.addView(label("T = 0.1–24 s. Each enabled channel waits T/N before sampling; processing adds small overhead.",12));
        schedule=label("8 channels · 0.125 s wait/channel",13); root.addView(schedule);
        for(int i=0;i<8;i++) {
            int ch=i; LinearLayout control=row(root);
            enabled[i]=new CheckBox(this); enabled[i].setText("CH"+i+" Enable"); enabled[i].setChecked(true); add(control,enabled[i]);
            gains[i]=new Spinner(this);
            gains[i].setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"25×","50×","100×","200×"}));
            add(control,gains[i]);
            enabled[i].setOnCheckedChangeListener((b,checked)->controlChanged());
            gains[i].setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override public void onItemSelected(AdapterView<?> p,View v,int position,long id) {
                    if(!syncing&&applied!=null&&position!=applied.gains[ch]) controlChanged();
                }
                @Override public void onNothingSelected(AdapterView<?> p) { }
            });
        }
        interval.setOnEditorActionListener((v,id,event)->{ applySettings(false); return true; });
        apply=button("Apply Settings",()->applySettings(false)); root.addView(apply);
        LinearLayout actions=row(root);
        start=button("Start",()->applySettings(true)); stop=button("Stop",this::stopSampling);
        add(actions,start); add(actions,stop); add(actions,button("Clear",this::clear));
        root.addView(label("Clear removes all charts and export history; existing CSV recordings are preserved. Charts retain every point until Clear or app exit.",12));
        LinearLayout files=row(root);
        record=button("Record to CSV",()->{ if(recording!=null) stopRecording(); else chooseFile(RECORD); }); add(files,record);
        add(files,button("Export All Data",()->chooseFile(EXPORT)));
        recordStatus=label("0 samples · 0 RSSI readings",13); root.addView(recordStatus);
        for(int i=0;i<8;i++) {
            values[i]=label("CH"+i+" · — mV",18); values[i].setTextColor(TrendView.COLORS[i]); root.addView(values[i]);
            charts[i]=new TrendView(this,"mV",TrendView.COLORS[i]); charts[i].clear(seconds());
            root.addView(charts[i],new LinearLayout.LayoutParams(-1,dp(190)));
        }
    }
    private void controlChanged() {
        if(syncing) return;
        updateSchedule(); main.removeCallbacks(liveApply);
        if(connected&&applied!=null&&target==null&&runTarget==null) main.postDelayed(liveApply,350);
    }
    private Protocol.Settings controls() {
        int mask=0; int[] states=new int[8];
        for(int i=0;i<8;i++) { if(enabled[i].isChecked()) mask|=1<<i; states[i]=gains[i].getSelectedItemPosition(); }
        return new Protocol.Settings(Protocol.interval(interval.getText().toString()),mask,states,false);
    }
    private void updateSchedule() {
        try {
            Protocol.Settings s=controls(); int n=Integer.bitCount(s.mask);
            schedule.setText(n==0?"No channels enabled · acquisition paused":String.format(Locale.US,"%d channels · %.4f s wait/channel",n,s.interval/1000.0/n));
        } catch(IllegalArgumentException e) { schedule.setText(e.getMessage()); }
    }
    private void applySettings(boolean startRequested) {
        main.removeCallbacks(liveApply);
        if(!connected||applied==null||target!=null||runTarget!=null) return;
        try {
            Protocol.Settings request=controls();
            if(startRequested&&request.mask==0) throw new IllegalArgumentException("Enable at least one channel before Start.");
            target=request; startAfterConfig=startRequested; ble.send(request.command()); armTimeout(); refresh();
            onStatus("Applying settings…");
        } catch(IllegalArgumentException e) { onStatus(e.getMessage()); }
    }
    private void stopSampling() {
        if(!connected||applied==null||target!=null||runTarget!=null) return;
        main.removeCallbacks(liveApply); runTarget=false; ble.send("R=0"); armTimeout(); refresh();
    }
    private void armTimeout() { main.removeCallbacks(commandTimeout); main.postDelayed(commandTimeout,8000); }
    private void refresh() {
        boolean free=connected&&applied!=null&&target==null&&runTarget==null;
        start.setEnabled(free&&!applied.running); stop.setEnabled(free&&applied.running); apply.setEnabled(free);
        interval.setEnabled(free);
        for(int i=0;i<8;i++) { enabled[i].setEnabled(free); gains[i].setEnabled(free); }
    }
    private void showSettings(Protocol.Settings s) {
        syncing=true; interval.setText(String.format(Locale.US,"%.3f",s.interval/1000.0));
        for(int i=0;i<8;i++) { enabled[i].setChecked((s.mask&(1<<i))!=0); gains[i].setSelection(s.gains[i]); }
        syncing=false; updateSchedule();
    }
    private void requestScan() {
        if(connected) { onStatus("Disconnect before scanning again."); return; }
        String[] p=Build.VERSION.SDK_INT>=31?new String[]{Manifest.permission.BLUETOOTH_SCAN,Manifest.permission.BLUETOOTH_CONNECT}:new String[]{Manifest.permission.ACCESS_FINE_LOCATION};
        for(String permission:p) if(checkSelfPermission(permission)!=PackageManager.PERMISSION_GRANTED) { requestPermissions(p,PERMISSIONS); return; }
        showScan();
    }
    @Override public void onRequestPermissionsResult(int code,String[] p,int[] results) {
        super.onRequestPermissionsResult(code,p,results);
        if(code!=PERMISSIONS||results.length==0) return;
        for(int r:results) if(r!=PackageManager.PERMISSION_GRANTED) { onStatus("Bluetooth permissions are required."); return; }
        showScan();
    }
    private void showScan() {
        devices.clear(); names.clear(); scanAdapter=new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,names);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Select CC2340 device")
                .setAdapter(scanAdapter,(d,index)->{ address=devices.get(index).getAddress(); ble.connect(devices.get(index)); })
                .setNegativeButton("Cancel",null).create();
        dialog.setOnDismissListener(d->ble.stopScan()); dialog.show(); ble.startScan();
    }
    @Override public void onDevice(BluetoothDevice device,String name,int scanRssi) {
        int index=-1;
        for(int i=0;i<devices.size();i++) if(devices.get(i).getAddress().equals(device.getAddress())) { index=i; break; }
        String title=name+"\n"+device.getAddress()+" · scan RSSI "+scanRssi+" dBm";
        if(index<0) { devices.add(device); names.add(title); } else names.set(index,title);
        scanAdapter.notifyDataSetChanged();
    }
    @Override public void onStatus(String text) { if(!closing) status.setText(text); }
    @Override public void onReady() {
        connected=true; connectionId++; onStatus("Connected. Checking firmware settings…");
        log("connected",null,null); refresh();
    }
    @Override public void onDisconnected() {
        if(connected) {
            log("disconnected",null,null);
            for(TrendView chart:charts) chart.add(seconds(),Double.NaN);
        }
        connected=false; applied=target=null; runTarget=null; startAfterConfig=false; latestRssi=null;
        main.removeCallbacks(commandTimeout); main.removeCallbacks(liveApply);
        if(!closing) refresh();
    }
    @Override public void onData(byte[] data) {
        try {
            if(data.length>0&&(data[0]&255)==0xc4) {
                Protocol.Settings s=Protocol.settings(data); applied=s;
                if(target!=null&&!target.matches(s)) return;
                target=null;
                if(startAfterConfig) {
                    startAfterConfig=false; runTarget=true; ble.send("R=1"); armTimeout();
                } else {
                    if(runTarget!=null&&s.running!=runTarget) return;
                    runTarget=null; main.removeCallbacks(commandTimeout); showSettings(s);
                    onStatus(s.running?"Sampling running.":"Ready. Click Start to sample.");
                }
                refresh(); return;
            }
            if(data.length==15&&(data[0]&255)==0xa5) {
                Protocol.Sample s=new Protocol.Sample(data);
                if(applied==null||!applied.running||runTarget!=null) return;
                boolean valid=s.millivolts!=0xffff;
                charts[s.channel].add(seconds(),valid?s.millivolts:Double.NaN);
                values[s.channel].setText("CH"+s.channel+" · "+(valid?s.millivolts+" mV":"ADC failed")+" · "+Protocol.GAINS[s.gain]+"×");
                sampleCount++; log("sample",s,null); counts(); return;
            }
            String text=new String(data,StandardCharsets.US_ASCII).trim();
            if(text.startsWith("ERR,")) {
                target=null; runTarget=null; startAfterConfig=false; main.removeCallbacks(commandTimeout);
                onStatus("Device rejected command: "+text+(text.equals("ERR,DEBUG")?". End CCS debugging and power-cycle the board.":""));
                if(applied!=null) showSettings(applied); refresh();
            } else onStatus("Older/incompatible firmware. Use the current phsense_wired project in CCS.");
        } catch(IllegalArgumentException e) { onStatus(e.getMessage()); }
    }
    @Override public void onRssi(Integer rssi) {
        if(closing) return;
        latestRssi=rssi;
        if(rssi==null) {
            rssiText.setText("RSSI: unavailable"); rssiChart.add(seconds(),Double.NaN);
            if(connected) log("rssi_unavailable",null,null);
            return;
        }
        latestRssiTime=SystemClock.elapsedRealtime(); signalStats.add(rssi);
        rssiText.setText("RSSI: "+rssi+" dBm");
        rssiStats.setText(String.format(Locale.US,"Mean %.1f · SD %.1f · Min %d · Max %d dBm · n=%d",signalStats.mean,signalStats.sd(),signalStats.min,signalStats.max,signalStats.count));
        rssiChart.add(seconds(),rssi); log("rssi",null,rssi); counts();
    }
    private double seconds() { return (SystemClock.elapsedRealtime()-origin)/1000.0; }
    private void counts() {
        recordStatus.setText(sampleCount+" samples · "+signalStats.count+" RSSI readings"+(recording!=null?" · Recording":""));
    }
    private void clear() {
        history.clear(); origin=SystemClock.elapsedRealtime(); sampleCount=0; signalStats.clear(); latestRssi=null;
        for(int i=0;i<8;i++) { charts[i].clear(0); values[i].setText("CH"+i+" · — mV"); }
        rssiChart.clear(0); rssiText.setText("RSSI: waiting for next reading"); rssiStats.setText("Statistics reset");
        log("clear",null,null); counts(); onStatus("Charts and export history cleared. Existing CSV recordings preserved.");
    }
    private void log(String event,Protocol.Sample s,Integer rssi) {
        String line=Telemetry.row(event,iso.format(new Date()),seconds(),connectionId,address,s,
                latestRssi,SystemClock.elapsedRealtime()-latestRssiTime,rssi);
        history.add(line);
        if(recording!=null) try { recording.write(line); recording.flush(); }
        catch(IOException e) { stopRecording(); onStatus("CSV recording failed: "+e.getMessage()); }
    }
    private void chooseFile(int request) {
        if(request==EXPORT&&history.isEmpty()) { onStatus("No data to export."); return; }
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("text/csv");
        i.putExtra(Intent.EXTRA_TITLE,"ph-sense-"+(request==RECORD?"recording-":"export-")+System.currentTimeMillis()+".csv");
        startActivityForResult(i,request);
    }
    @Override protected void onActivityResult(int request,int result,Intent data) {
        super.onActivityResult(request,result,data);
        if(result!=RESULT_OK||data==null||data.getData()==null) return;
        Uri uri=data.getData();
        if(request==RECORD) {
            try {
                OutputStream stream=getContentResolver().openOutputStream(uri,"wt");
                if(stream==null) throw new IOException("Cannot open CSV file.");
                recording=new BufferedWriter(new OutputStreamWriter(stream,StandardCharsets.UTF_8));
                recording.write(HEADER); recording.flush(); record.setText("Stop Recording"); counts(); onStatus("Recording future readings to CSV.");
            } catch(IOException e) { stopRecording(); onStatus("Cannot record CSV: "+e.getMessage()); }
        } else if(request==EXPORT) {
            ArrayList<String> copy=new ArrayList<>(history);
            new Thread(()->{
                try(OutputStream stream=getContentResolver().openOutputStream(uri,"wt")) {
                    if(stream==null) throw new IOException("Cannot open CSV file.");
                    try(Writer writer=new BufferedWriter(new OutputStreamWriter(stream,StandardCharsets.UTF_8))) {
                        writer.write(HEADER); for(String line:copy) writer.write(line);
                    }
                    main.post(()->onStatus("Exported "+copy.size()+" events, including samples and RSSI."));
                } catch(IOException e) { main.post(()->onStatus("Export failed: "+e.getMessage())); }
            },"csv-export").start();
        }
    }
    private void stopRecording() {
        if(recording!=null) try { recording.close(); } catch(IOException e) { onStatus("CSV close failed: "+e.getMessage()); }
        recording=null; record.setText("Record to CSV"); counts();
    }
    @Override protected void onDestroy() {
        closing=true; main.removeCallbacksAndMessages(null); ble.stopScan(); ble.disconnect(); stopRecording(); super.onDestroy();
    }
}
