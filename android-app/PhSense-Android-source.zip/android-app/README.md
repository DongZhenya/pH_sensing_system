# pH Sense Android app

Android 8.0+ app for the custom CC2340R53 board. Version 0.2.0-rssi uses the same
Start-enabled, per-channel protocol as the current Windows application. OTA has been removed.
Install `app/build/outputs/apk/debug/app-debug.apk`, or the named APK in
`../outputs/phsense-android-rssi-20261021/`.

## Usage

1. Keep the current `wired_firmware` / `phsense_wired` firmware programmed through CCS/XDS110.
   No MCUboot, OAD, or new RSSI firmware is needed. Older 20-byte sweep firmware is incompatible.
2. Disconnect the Windows app, SimpleLink Connect and other BLE clients. Power the PCB normally.
3. Open pH Sense on the phone. Choose **Scan / Connect**, grant permissions and select the PCB.
   Android 8–11 may also require the phone's Location service to be enabled for BLE scanning.
4. Wait for **Ready. Click Start to sample.** Connected RSSI starts automatically, even before Start.
5. Enter T = 0.1–24 seconds (up to three decimal places), choose the enabled channels and independent
   INA225 gains (25/50/100/200x). Gain/channel changes apply automatically after a short debounce;
   use **Apply Settings** for a manually entered interval.
6. **Start** confirms all settings, then enables sampling. **Stop** stops sampling but keeps BLE/RSSI active.
   Neither connecting nor changing settings automatically starts an idle board.
7. Each selected channel is switched in with its own gain, waits T/N seconds, is measured and reported
   immediately, then the next enabled channel is selected. Actual cycle time includes processing overhead.
   Selecting zero channels pauses channel acquisition. C2:B2:B1 encodes the channel number.
8. Eight independent line charts retain all raw readings and automatically scale their Y axes. The X axis
   expands for the entire session; no rolling 60-second window or downsampling is used. Screen refresh is
   throttled to reduce drawing load, not to discard readings. Finite screen width still limits visual detail
   over long sessions. ADC failures and disconnections break traces.
9. **Clear** removes charts, displayed channel values, RSSI statistics and export history. It does not stop
   sampling, change settings or erase an existing CSV recording. The elapsed-time origin resets and a
   `clear` event is recorded. **Export All Data** exports a snapshot of history since Clear.
10. **Record to CSV** chooses a file and records future events continuously; **Stop Recording** closes it.
    Recording does not implicitly start sampling. Keep the app foregrounded; the screen is kept awake.
    There is no background BLE service, process-death recovery or automatic reconnection. Rotation keeps
    the Activity and its data. Data remain in RAM until Clear or app exit; use CSV recording for persistence.

## RSSI measurement

The phone calls Android `BluetoothGatt.readRemoteRssi()` approximately once per second after the
notification subscription is ready. This is the signal received **by this phone from the PCB** during
the connection. It is not the signal received by a computer, not measured transmit power, and not a
per-sample radio measurement. Command writes and RSSI reads share a serialized GATT queue with
timeouts; no extra firmware writes or GATT characteristics are needed for RSSI.

The live number, cumulative line chart and mean/sample SD/min/max use successful RSSI callbacks only.
Failed reads and stale readings are shown as unavailable, never as 0 dBm. Failed reads break the RSSI
trace. The app's SD describes temporal variation in one recording, not independent experimental repeats.
The scan dialog shows **scan RSSI** separately; these values are not included in connected RSSI logs.

For distance experiments use the same phone, board orientation/height, firmware, configured TX power,
sampling settings and environment. At each distance Clear, record for 60 s, then export and label the
file with distance and trial. Repeat independently. Record connection loss separately. Reading RSSI
and using a different central can affect connection behavior; do not compare power measurements with
different BLE configurations as if they were identical.

## CSV

UTF-8 columns:

`event,phone_time,elapsed_s,connection_id,device_address,channel,gain_v_per_v,vsen_mv,adc_valid,sequence,device_time_ms,cycle,rssi_dbm,rssi_age_ms`

- `sample`: one reported channel conversion; ADC failures remain rows with empty voltage and adc_valid=0.
  Device time and cycle are unsigned 32-bit counters from firmware; sequence wraps at 256.
  RSSI, when present, is the latest successful reading no more than 3 s old; its age is explicit.
- `rssi`: one successful connected RSSI read, with its own phone timestamp, even when sampling is stopped.
  **Filter event=rssi for RSSI statistics**, rather than counting duplicated latest-RSSI values on sample rows.
- `connected`, `disconnected`, `rssi_unavailable`, `clear`: session/missing-data markers with blank RSSI.

Phone timestamps describe callback reception, not exact RF packet transmission. Historical samples and
RSSI values are not capped, but available phone memory is finite. CSV recording flushes each event;
unplugging or killing the app may still lose in-flight OS/provider buffers. Existing recording files are
not retroactively changed by Clear or by exporting a new snapshot.

## Build and checks

Open this folder in Android Studio and build the app with Android SDK 35 and Java 17+.
The existing wrapper uses Gradle 9.6.0 and Android Gradle Plugin 8.9.2; the Gradle build/lint path
could not be validated in the restricted build environment because Gradle rejected the directory's
permission check. The delivered APK was instead compiled, dexed, packaged, aligned and signed using
the installed SDK tools via `build-apk.ps1` (no third-party runtime dependencies).

Fallback build:

```powershell
./build-apk.ps1 -Sdk 'C:/path/to/Android/Sdk' -Jdk 'C:/path/to/jdk' -DebugKeystore 'C:/path/to/debug.keystore'
```

The script runs 82 pure-Java protocol/RSSI-statistics/CSV checks and verifies the APK v2/v3 signature,
package, launch Activity and SDK levels. It uses the local Android debug key, versionCode 2,
versionName 0.2.0-rssi. This is a development APK, not a Play Store release.
The small APK size is expected: all UI is native Android, without large third-party libraries.

**No phone/emulator was connected during development. Real-phone UI, BLE stability, gain/timing,
RSSI validity and long-duration recording still require hardware verification.**
